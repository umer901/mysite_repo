from django.urls import path, re_path
from . import views

urlpatterns = [
path("home/", views.home, name="home"),
path("", views.home, name="home"),
path("register/", views.register, name="register"),
path("login/", views.login_request, name="login"),
path("change_password", views.change_password, name='change_password'),
path("courses", views.courses, name='courses'),
# path('update', views.update, name='update'),
path('profile/<username>', views.profile, name='profile'),



]