from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from .forms import RegisterForm, UserUpdateForm
from django.contrib.auth import login, authenticate, logout, update_session_auth_hash, get_user_model
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import messages
from django.db import connection
from .models import Students, Courses


def register(response):
    if response.method == "POST" :
        form = RegisterForm(response.POST)
        if form.is_valid():
            form.save()
        redirect('home/')
    else:
        form = RegisterForm()

    # form[1]

    return render(response, "main/register.html", {"form":form})


def home(request):
    cursor = connection.cursor()
    cursor.execute("select student_name from students")
    # cursor.close()
    query = cursor.fetchall()
    newq = []
    for x in query:
        newq.append(x[0].split()[0] + " " + x[0].split()[1]);
    return render(request, 'main/home.html',{'query': newq})

def courses(request):
    

    if request.method == "POST":
        searched = request.POST['searched']
        cursor = connection.cursor()
        q = "select course_name, instructor_name, department_name, credit_hours, semester from courses INNER JOIN instructor on instructor.instructor_id = courses.instructor_id where course_name LIKE'%"+searched+"%' OR instructor_name LIKE '%"+searched+"%' OR department_name LIKE '%"+searched+"%' OR credit_hours LIKE '%"+searched+"%'"
        cursor.execute(q)
        query = cursor.fetchall()

        return render(request, 'main/courses.html', {'searched':searched,'Courses':query})
    else:
        return render(request, 'main/course.html', {})


# def update(request):
#     cursor = connection.cursor()
#     cursor.execute("select course_name, credit_hours, prereqs_names from courses INNER JOIN prereqs ON prereqs.course_ID = courses.course_ID")
#     # cursor.close()
#     query = cursor.fetchall()
#     newq = []
#     return render(request, 'main/update.html',{'query': query})

def profile(request, username):
    cursor = connection.cursor()
    cursor.execute("select course_name, credit_hours, prereqs_names from courses INNER JOIN prereqs ON prereqs.course_ID = courses.course_ID")
    # cursor.close()
    query = cursor.fetchall()

    if request.method == 'POST':
        user = request.user
        form = UserUpdateForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            user_form = form.save()

            messages.success(request, f'{user_form}, Your profile has been updated!')
            return redirect('profile', user_form.username)

        for error in list(form.errors.values()):
            messages.error(request, error)
    user = get_user_model().objects.filter(username=username).first()

    if user:
        form = UserUpdateForm(instance=user)
        form.fields['username'].widget.attrs = {'rows': 1}
        return render(request, 'main/profile.html', context={'form': form, 'query':query})

    return redirect("homepage")



def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"You are now logged in as {username}.")
				return redirect("/")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request, template_name="main/login.html", context={"login_form":form})

def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, 'Your password was successfully updated!')
            return redirect('change_password')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'main/change_password.html', {'form': form})
